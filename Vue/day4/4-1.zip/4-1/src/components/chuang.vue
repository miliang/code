<template>
  <div>
    床的组件
  </div>
</template>
<style scoped>

</style>
<script>
  export default{
    data () {
      return {
        msg: 'hello vue'
      }
    },
    components: {}
  }
</script>
